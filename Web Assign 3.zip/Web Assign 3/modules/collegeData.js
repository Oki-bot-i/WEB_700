const fs = require("fs");

class Data {
  constructor(students, courses) {
    this.students = students;
    this.courses = courses;
  }
}

let dataCollection = null;

module.exports.initialize = function () {
  return new Promise((resolve, reject) => {
    fs.readFile('./data/courses.json', 'utf8', (err, courseData) => {
      if (err) {
        reject("Unable to load courses: " + err);
        return;
      }

      fs.readFile('./data/students.json', 'utf8', (err, studentData) => {
        if (err) {
          reject("Unable to load students: " + err);
          return;
        }

        try {
          const students = JSON.parse(studentData);
          const courses = JSON.parse(courseData);
          dataCollection = new Data(students, courses);
          resolve();
        } catch (parseError) {
          reject("Error parsing JSON data: " + parseError);
        }
      });
    });
  });
};

module.exports.getAllStudents = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    if (dataCollection.students.length === 0) {
      reject("No students found");
    } else {
      resolve(dataCollection.students);
    }
  });
};

module.exports.getTAs = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const filteredStudents = dataCollection.students.filter(student => student.TA === true);

    if (filteredStudents.length === 0) {
      reject("No TAs found");
    } else {
      resolve(filteredStudents);
    }
  });
};

module.exports.getCourses = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    if (dataCollection.courses.length === 0) {
      reject("No courses found");
    } else {
      resolve(dataCollection.courses);
    }
  });
};

module.exports.getStudentByNum = function (num) {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const foundStudent = dataCollection.students.find(student => student.studentNum === num);

    if (!foundStudent) {
      reject("Student not found");
    } else {
      resolve(foundStudent);
    }
  });
};

module.exports.getStudentsByCourse = function (course) {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const filteredStudents = dataCollection.students.filter(student => student.course === course);

    if (filteredStudents.length === 0) {
      reject("No students found for the course: " + course);
    } else {
      resolve(filteredStudents);
    }
  });
};

module.exports.addStudent = (studentData) => {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    if (studentData.TA === undefined) {
      studentData.TA = false;
    } else {
      studentData.TA = true;
    }
    studentData.studentNum = dataCollection.students.length + 1;
    dataCollection.students.push(studentData);
    resolve();
  });
};
