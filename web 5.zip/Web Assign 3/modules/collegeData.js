const fs = require("fs");

class Data {
  constructor(students, courses) {
    this.students = students;
    this.courses = courses;
  }
}

let dataCollection = null;

// Initialize function to load and parse JSON data
module.exports.initialize = function () {
  return new Promise((resolve, reject) => {
    fs.readFile('./data/courses.json', 'utf8', (err, courseData) => {
      if (err) {
        console.error("Unable to load courses:", err); // Log error
        reject("Unable to load courses: " + err);
        return;
      }

      fs.readFile('./data/students.json', 'utf8', (err, studentData) => {
        if (err) {
          console.error("Unable to load students:", err); // Log error
          reject("Unable to load students: " + err);
          return;
        }

        try {
          const students = JSON.parse(studentData);
          const courses = JSON.parse(courseData);
          dataCollection = new Data(students, courses);
          resolve();
        } catch (parseError) {
          console.error("Error parsing JSON data:", parseError); // Log error
          reject("Error parsing JSON data: " + parseError);
        }
      });
    });
  });
};

// Function to get all students
module.exports.getAllStudents = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    resolve(dataCollection.students);
  });
};

// Function to get TAs
module.exports.getTAs = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const filteredStudents = dataCollection.students.filter(student => student.TA === true);
    resolve(filteredStudents);
  });
};

// Function to get all courses
module.exports.getCourses = function () {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    resolve(dataCollection.courses);
  });
};

// Function to get a student by student number
module.exports.getStudentByNum = function (num) {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const foundStudent = dataCollection.students.find(student => student.studentNum === parseInt(num));
    if (foundStudent) {
      resolve(foundStudent);
    } else {
      reject("Student not found");
    }
  });
};

// Function to get students by course
module.exports.getStudentsByCourse = function (course) {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const filteredStudents = dataCollection.students.filter(student => student.course === parseInt(course));
    resolve(filteredStudents);
  });
};

// Function to add a new student
module.exports.addStudent = (studentData) => {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    if (studentData.TA === undefined) {
      studentData.TA = false;
    }
    studentData.studentNum = dataCollection.students.length + 1;
    dataCollection.students.push(studentData);
    resolve();
  });
};

// Function to update student information
module.exports.updateStudent = (studentData) => {
  return new Promise((resolve, reject) => {
    if (!dataCollection) {
      reject("Data collection not initialized");
      return;
    }

    const index = dataCollection.students.findIndex(student => student.studentNum == studentData.studentNum);
    if (index !== -1) {
      // Handle TA checkbox
      studentData.TA = studentData.TA === 'on';
      
      dataCollection.students[index] = studentData;
      resolve();
    } else {
      reject("Student not found");
    }
  });
};
